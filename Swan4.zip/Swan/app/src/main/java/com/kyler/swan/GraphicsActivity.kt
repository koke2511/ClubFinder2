package com.kyler.swan

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.facebook.ads.AdSize
import com.facebook.ads.AudienceNetworkAds
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.formatter.DefaultValueFormatter
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import com.github.mikephil.charting.utils.ColorTemplate
import com.google.android.gms.ads.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.graphics_layout.*
import kotlinx.android.synthetic.main.plus_layout.*
import java.util.*
import com.facebook.ads.*
import com.facebook.ads.AdView
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places


const val plusButtonState = "1"

class GraphicsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private lateinit var mapView: MapView

    lateinit var mainActivity: MainActivity
    lateinit var reservaDao: ReservaDao



    data class Disco(val name: String, val location: LatLng)

    val discotecas = listOf(
        Disco ("Ubicacion", LatLng(40.42934264054745, -3.7128884026577316)), // Las coordenadas de "Disco 1"
        Disco("Cats", LatLng(40.442981466877555, -3.7134420026075587)), // Las coordenadas de "Disco 1"
        Disco("Barcelo", LatLng(40.42710512500776, -3.6997970051797067)), // Las coordenadas de "Disco 2"
        Disco("Nuit", LatLng(40.448943720524106, -3.6950045355821124)), // Las coordenadas de "Disco 3"
        Disco("Joy", LatLng(40.41733520616386, -3.706533916101031)), // Las coordenadas de "Disco 4"
        Disco("Posh", LatLng(40.45042979312278, -3.694803187264189)), // Las coordenadas de "Disco 5"
        // Añade más discotecas aquí...
    )




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.graphics_layout)



        mapView = findViewById(R.id.mapView)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)
        Places.initialize(applicationContext, "AIzaSyBdGAWhODceEVzLPHDz3IpFgbUzJuKnoQU")



        mainActivity = MainActivity()


        reservaDao = AppDatabase.getInstance(this).reservaDao()

        val reservas = ArrayList<Reserva>(reservaDao.getReservas())

        println(reservas.size)


        boton_lista_discoteca.setOnClickListener {
            startActivity(Intent(this, Activity_discotecas::class.java))
        }





        //Barra de navegación inferior
        var mbottomNavigation: BottomNavigationView? = null

        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        val width = metrics.widthPixels // ancho absoluto en pixels
        val height = metrics.heightPixels // alto absoluto en pixels

        println("width: $width height: $height")


        mbottomNavigation = findViewById<View>(R.id.bottomNavigation) as BottomNavigationView

        if (width == 1080){
            mbottomNavigation.itemIconSize = 150
        }
        else if (width == 720){
            mbottomNavigation.itemIconSize = 100
        }
        mbottomNavigation.setOnNavigationItemSelectedListener { item ->
            if (item.itemId == R.id.home_button) {
                val intent1 = Intent(this, MainActivity::class.java)
                intent1.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent1)
            }
            if (item.itemId == R.id.plus_button) {
                val intent2 = Intent(this, MainActivity::class.java).putExtra(plusButtonState, "true").putExtra(
                    editar, "false")
                intent2.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent2)
            }
            if (item.itemId == R.id.graphics_button) {
                val intent3 = Intent(this, GraphicsActivity::class.java)
                intent3.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent3)
            }
            true
        }


        }



    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.uiSettings.isZoomControlsEnabled = true



        /*//codigo que muestre las discotecas cecanas a la posicion del usuario
        val placesClient = Places.createClient(this)
        val location = LatLng(40.429796, -3.707531)
        val request = FetchPlaceRequest.newInstance("supermercado", listOf(ID, NAME, ADDRESS, LAT_LNG, RATING, USER_RATINGS_TOTAL, OPENING_HOURS))

        placesClient.fetchPlace(request).addOnSuccessListener { response ->
            val place = response.place
            val location = place.latLng
            val markerOptions = MarkerOptions().position(location!!).title(place.name)
            map.addMarker(markerOptions)
        }

        //codigo que muestre las discotecas cecanas a la posicion del usuario
        map.addMarker(MarkerOptions().position(location).title("Marker in Madrid"))*/


        // Añade un marcador para cada discoteca en la lista
        for (disco in discotecas) {
            map.addMarker(MarkerOptions().position(disco.location).title(disco.name))
            println("Instanciada la discoteca ${disco.name}")
        }

        // Centra el mapa en Madrid
        val madrid = LatLng(40.42934264054745, -3.7128884026577316)





        map.moveCamera(com.google.android.gms.maps.CameraUpdateFactory.newLatLngZoom(madrid, 12f))
    }


    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        mapView.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    }




