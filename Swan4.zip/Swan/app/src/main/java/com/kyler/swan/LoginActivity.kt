package com.kyler.swan


import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.ktx.auth

import com.google.firebase.ktx.Firebase
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.android.synthetic.main.activity_login.*
import java.security.Provider


class LoginActivity : AppCompatActivity() {

    private val GOOGLE_SIGN_IN = 100

    lateinit var mainActivity: MainActivity
    lateinit var settingsActivity: SettingsActivity

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_login)

        mainActivity = MainActivity()



            //Setup
            notification()
            setup()


}


    private fun notification(){

        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val token = task.result
                token?.let {
                    println("Este es el token del dispositivo: ${it}")
                }
            } else {
                // Error al obtener el token
            }
        }
    }


    private fun setup(){

        title = "Autenticacion"



        log_in.setOnClickListener {
            if (edadEditText != null && edadEditText.text.toString().toInt() >= 18){
                showHome()

            } else {
                showAlert()
            }

            if(nombreEditText != null || primerApellidoEditText != null || dniEditText != null || edadEditText != null){
                val builder = AlertDialog.Builder(this)
                builder.setTitle("Error")
                builder.setMessage("Rellena todos los campos.")
                builder.setPositiveButton("Aceptar", null)
                val dialog: AlertDialog = builder.create()
                dialog.show()
            } else {
                showAlert()
            }


        }



    }


    private fun showAlert(){
        println("Error")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Error")
        builder.setMessage("El usuario debe tener al menos 18 años.")
        builder.setPositiveButton("Aceptar", null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    private fun showHome(){
        estadoInicio = false

        nombreApellido = nombreEditText.text.toString() + " " + primerApellidoEditText.text.toString() + " "

        val homeIntent = Intent(this, MainActivity::class.java)

        startActivity(homeIntent)


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GOOGLE_SIGN_IN){

            val task = GoogleSignIn.getSignedInAccountFromIntent(data)

            try {
                val account = task.getResult(ApiException::class.java)

                if(account != null){

                    val credential = GoogleAuthProvider.getCredential(account.idToken, null)

                    FirebaseAuth.getInstance().signInWithCredential(credential).addOnCompleteListener{

                        if (it.isSuccessful){
                            showHome()
                        } else {
                            showAlert()
                            println("Error")
                        }


                    }

                }
            } catch (e: ApiException){
                showAlert()
            }

        }
    }
}