package com.kyler.swan

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.DisplayMetrics
import android.view.View
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.ads.MobileAds
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.analytics.FirebaseAnalytics
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.plus_layout.direccion


var estado_Inicio  = true

class Activity_discotecas: AppCompatActivity(){

    val     plusButtonCode = 1

    lateinit var discotecaAdapter: DiscotecaAdapter
    lateinit var mainLayout : CoordinatorLayout



    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_discotecas)


        val discotecas = ArrayList<Discoteca>()
        discotecas.add(Discoteca ("Cats", "Calle1"))
        discotecas.add(Discoteca ("Barcelo", "Calle2"))
        discotecas.add(Discoteca ("Nuit", "Calle3"))
        discotecas.add(Discoteca ("Joy", "Calle4"))
        discotecas.add(Discoteca ("Posh", "Calle5"))

        discotecaAdapter = DiscotecaAdapter(discotecas,this)
        recycler_view.adapter = discotecaAdapter
        recycler_view.layoutManager = LinearLayoutManager(this)
        recycler_view.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))

        val itemTouchHelperCallback = object : ItemTouchHelper.Callback() {
            override fun getMovementFlags(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder
            ): Int {
                return makeMovementFlags(ItemTouchHelper.UP.or(ItemTouchHelper.DOWN), ItemTouchHelper.RIGHT)
            }

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val posicionInicial = viewHolder.adapterPosition
                val posicionFinal = target.adapterPosition
                discotecaAdapter.cambiarPosicionItem(posicionInicial, posicionFinal)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val posicion = viewHolder.adapterPosition
                val tarea = discotecaAdapter.getDiscoteca(posicion)
                discotecaAdapter.eliminarDiscoteca(posicion)
                val snackbar = Snackbar.make(findViewById(R.id.activity_content), "Eliminaste una tarea", Snackbar.LENGTH_LONG)
                snackbar.setAction("Deshacer") {
                    discotecaAdapter.restaurarDiscoteca(posicion, tarea)
                }
                snackbar.setActionTextColor(Color.YELLOW)
                //snackbar.apply {view.layoutParams = (view.layoutParams as CoordinatorLayout.LayoutParams).apply {setMargins(0, topMargin, rightMargin, 500)}}.show()
            }

        }

        val itemTouchHelper = ItemTouchHelper(itemTouchHelperCallback)
        itemTouchHelper.attachToRecyclerView(recycler_view)

        settings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }



        //Barra de navegación inferior
        var mbottomNavigation: BottomNavigationView? = null

        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        val width = metrics.widthPixels // ancho absoluto en pixels
        val height = metrics.heightPixels // alto absoluto en pixels

        println("width: $width height: $height")


        mbottomNavigation = findViewById<View>(R.id.bottomNavigation) as BottomNavigationView

        if (width == 1080){
            mbottomNavigation.itemIconSize = 150
        }
        else if (width == 720){
            mbottomNavigation.itemIconSize = 100
        }

        mbottomNavigation!!.setOnNavigationItemSelectedListener { item ->
            if (item.itemId == R.id.home_button) {
                val intent1 = Intent(this, MainActivity::class.java)
                intent1.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent1)
            }
            if (item.itemId == R.id.plus_button) {
                val intent2 = Intent(this, PlusActivity::class.java)
                intent2.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivityForResult(intent2, plusButtonCode)
            }
            if (item.itemId == R.id.graphics_button) {
                val intent3 = Intent(this, GraphicsActivity::class.java)
                intent3.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent3)
            }
            true
        }



    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == plusButtonCode) {
            if(resultCode == Activity.RESULT_OK) {
                val discotecaDescripcion = data!!.extras!!["editText_discoteca"] as String
                val fecha = data!!.extras!!["fecha"] as String
                val dinero = data!!.extras!!["dinero"] as String
                val tipo = "no funciona"
                val direccion = data!!.extras!!["direccion"] as String



                val discotecaCreada = Discoteca(discotecaDescripcion, fecha)
                discotecaAdapter.agregarDiscoteca(discotecaCreada)
            }
        }
    }


}

