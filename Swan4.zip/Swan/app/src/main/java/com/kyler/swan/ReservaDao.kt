package com.kyler.swan

import androidx.room.*

@Dao
interface ReservaDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertarReserva(reserva: Reserva)

    @Update
    fun actualizarReserva(reserva: Reserva)

    @Delete
    fun eliminarReserva(reserva: Reserva)

    @Query("SELECT * FROM reserva")
    fun getReservas(): List<Reserva>
}