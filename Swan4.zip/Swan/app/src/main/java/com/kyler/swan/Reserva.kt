package com.kyler.swan

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reserva")
data class Reserva(
    @PrimaryKey val nombre: String,
    var fecha: String,
    var dinero : String,
    var tipo : String,
    var direccion : String
)