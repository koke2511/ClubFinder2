package com.kyler.swan

import android.app.*
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth


import kotlinx.android.synthetic.main.activity_settings.*


var nombreApellido = ""

lateinit var mainActivity: MainActivity

class SettingsActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)


        mainActivity = MainActivity()

        //Barra de navegación inferior
        var mbottomNavigation: BottomNavigationView? = null

        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        val width = metrics.widthPixels // ancho absoluto en pixels
        val height = metrics.heightPixels // alto absoluto en pixels

        println("width: $width height: $height")


        mbottomNavigation = findViewById<View>(R.id.bottomNavigation) as BottomNavigationView

        if (width == 1080){
            mbottomNavigation.itemIconSize = 150
        }
        else if (width == 720){
            mbottomNavigation.itemIconSize = 100
        }

        mbottomNavigation!!.setOnNavigationItemSelectedListener { item ->
            if (item.itemId == R.id.home_button) {
                val intent1 = Intent(this, MainActivity::class.java)
                intent1.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent1)
            }
            if (item.itemId == R.id.plus_button) {
                val intent2 = Intent(this, MainActivity::class.java).putExtra(
                    plusButtonState, "true").putExtra(editar, "false")
                intent2.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent2)
            }
            if (item.itemId == R.id.graphics_button) {
                val intent3 = Intent(this, GraphicsActivity::class.java)
                intent3.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent3)
            }
            true
        }

        acerca_de_boton.setOnClickListener {
            startActivity(Intent(this, acerca_de::class.java))
        }





        //usuario.setOnClickListener { showAlert(email ?: "", provider ?: "")}

        feedback.setOnClickListener {
            val uri: Uri =  Uri.parse("https://play.google.com")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }


        val prefs = PreferenceManager.getDefaultSharedPreferences(this)


        println("Nombre:" + nombreApellido)
        usuarioTextView.text = nombreApellido

    }






    private fun showAlert(email: String, provider: String){
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Informacion del usuario")
        builder.setMessage("Correo: $email\nProvedor: $provider")
        builder.setPositiveButton(
            "Cerrar sesión",
            DialogInterface.OnClickListener { dialogInterface: DialogInterface, i: Int ->
                FirebaseAuth.getInstance().signOut()




                startActivity(Intent(this, MainActivity::class.java))

            })
        builder.setNegativeButton("Volver", null)

        val dialog: AlertDialog = builder.create()
        dialog.show()
    }


}