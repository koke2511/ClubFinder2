package com.kyler.swan

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.icu.util.Calendar
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.view.View
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.facebook.ads.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.plus_layout.*

class PlusActivity : AppCompatActivity() {

    lateinit var reservaDao: ReservaDao
    lateinit var reservaAdapter: ReservaAdapter

    //lateinit var mAdView : AdView

    private var adView1: AdView? = null


    @RequiresApi(Build.VERSION_CODES.N)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.plus_layout)

        AudienceNetworkAds.initialize(this)

        adView1 = AdView(this, "630996857619608_635085820544045", AdSize.BANNER_HEIGHT_50)

        banner_container1.addView(adView1)


        adView1!!.loadAd()



        reservaDao = AppDatabase.getInstance(this).reservaDao()

        val reservas = java.util.ArrayList<Reserva>(reservaDao.getReservas())

        reservaAdapter = ReservaAdapter(reservas, this)



        //Button click to show DatePickerDialog
        diaPago.setOnClickListener {
            val c= Calendar.getInstance()
            val year= c.get(Calendar.YEAR)
            val month = c.get(Calendar.MONTH)
            val day = c.get(Calendar.DAY_OF_MONTH)
            var dpd = DatePickerDialog(
                this,
                DatePickerDialog.OnDateSetListener { view, mYear, mMonth, mDay ->
                    val mmMonth = mMonth + 1
                    var contadorDia = mDay.toString()
                    var contadorMes = mmMonth.toString()

                    if (mDay < 10) {
                        contadorDia = "0" + contadorDia
                    }
                    if (mmMonth < 10) {
                        contadorMes = "0" + contadorMes
                    }

                    val date = "$contadorDia/$contadorMes/$mYear"
                    diaPago.setText(date)
                },
                year,
                month,
                day
            )
            println(day)
            println(month)
            dpd.getDatePicker().setMinDate(System.currentTimeMillis() - 1000)
            dpd.show()
            dpd
        }

        val editar = intent.getStringExtra("Editar")

        val nombre_reserva = intent.getStringExtra("nombre")


        if (editar == "true"){

            println("Has entrado en el modo editar 2")

            //Titulo
            plusTextView.text = "Editar"


            //Nombre
            editText_reserva.setText(nombre_reserva)
            editText_reserva.isEnabled = false

            //Fecha
            val fecha_reserva = intent.getStringExtra("fecha")
            diaPago.setText(fecha_reserva)

            //Dinero
            val dinero_reserva = intent.getStringExtra("dinero")
            dinero.setText(dinero_reserva)

            val direccion_reserva = intent.getStringExtra( "direccion")
            println(direccion_reserva)
            direccion.setText(direccion_reserva)

            //Boton
            agregar_reserva.text = "Guardar cambios"
        }


        //Mecanismo para hallar la posicion
        var s = 0
        fun posicion(): Int{
            var b = 0
            while (s < reservas.size){

                if (reservas[s].nombre == nombre_reserva){

                    b = s
                }

                s++
            }
            return b
        }



        agregar_reserva.setOnClickListener{


            val nombre = editText_reserva.text.toString()
            val fecha = diaPago.text.toString()
            val dinero = dinero.text.toString()
            //var tipo = "tipo"
            val direccion = direccion.text.toString()


            if(nombre.isNotEmpty() && fecha.isNotEmpty() && dinero.isNotEmpty() && editar == "true"){

                println("Has entrado en el modo editar 3")

                //println(tipo)

                val intent = Intent()
                intent.putExtra("editText_reserva", nombre)
                intent.putExtra("fecha", fecha)
                intent.putExtra("dinero", dinero)
                //intent.putExtra("tipo", tipo)
                intent.putExtra("direccion", direccion)

                setResult(Activity.RESULT_OK, intent)

                //eliminarReserva(reservaes[posicion()], posicion())

                finish()
                println(fecha)
                Thread.sleep(500)

                startActivity(Intent(this, MainActivity::class.java))

            }

            if(nombre.isNotEmpty() && fecha.isNotEmpty() && dinero.isNotEmpty()){
                val intent = Intent()
                intent.putExtra("editText_reserva", nombre)
                intent.putExtra("fecha", fecha)
                intent.putExtra("dinero", dinero)
                //intent.putExtra("tipo", tipo)
                intent.putExtra("direccion", direccion)

                //println(tipo)

                println("añadir")

                setResult(Activity.RESULT_OK, intent)
                finish()
                println(fecha)

            }


        }



        //Barra de navegación inferior
        var mbottomNavigation: BottomNavigationView? = null

        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        val width = metrics.widthPixels // ancho absoluto en pixels
        val height = metrics.heightPixels // alto absoluto en pixels

        println("width: $width height: $height")


        mbottomNavigation = findViewById<View>(R.id.bottomNavigation) as BottomNavigationView

        if (width == 1080){
            mbottomNavigation.itemIconSize = 150
        }
        else if (width == 720){
            mbottomNavigation.itemIconSize = 100
        }

        mbottomNavigation.setOnNavigationItemSelectedListener { item ->
            if (item.itemId == R.id.home_button) {
                val intent1 = Intent(this, MainActivity::class.java)
                intent1.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent1)
            }
            if (item.itemId == R.id.plus_button) {
                val intent2 = Intent(this, PlusActivity::class.java)
                intent2.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent2)
            }
            if (item.itemId == R.id.graphics_button) {
                val intent3 = Intent(this, GraphicsActivity::class.java)
                intent3.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent3)
            }
            true
        }


    }



    fun eliminarReserva(reserva: Reserva, Posicion: Int){
        reservaDao.eliminarReserva(reserva)
        reservaAdapter.eliminarReserva(Posicion)
        val intent1 = Intent(this, MainActivity::class.java)
        intent1.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent1)
    }


    fun diaTotal(dia: Int, mes: Int) : Int{
        var diasTotales = 0

        val meses = ArrayList<Int>()

        var m = 0

        meses.add(0, 31)
        meses.add(1, 29)
        meses.add(2, 31)
        meses.add(3, 30)

        meses.add(4, 31)
        meses.add(5, 30)
        meses.add(6, 31)
        meses.add(7, 31)

        meses.add(8, 30)
        meses.add(9, 31)
        meses.add(10, 30)
        meses.add(11, 31)

        var diasDelMes = 0

        var diasDelMesRestantes = 0
        while (m < mes){
            diasDelMesRestantes = meses[m] - dia
            diasDelMes = diasDelMes + meses[m]
            m++
        }



        diasTotales = diasDelMes - diasDelMesRestantes
        return diasTotales
    }


}
