package com.kyler.swan

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.reserva_info.*
import java.util.*


const val editar = "1"

class Reserva_info : AppCompatActivity() {

    lateinit var plusActivity: PlusActivity
    lateinit var reservaAdapter: ReservaAdapter
    lateinit var mainActivity: MainActivity
    lateinit var reservaDao: ReservaDao

    var dias1: String? = null

    override fun onCreate(savedInstance: Bundle?) {
        super.onCreate(savedInstance)
        setContentView(R.layout.reserva_info)

        mainActivity = MainActivity()

        reservaDao = AppDatabase.getInstance(this).reservaDao()

        val reservas = ArrayList<Reserva>(reservaDao.getReservas())

        reservaAdapter = ReservaAdapter(reservas,this)


        plusActivity = PlusActivity()



        //Nombre
        val nombre_reserva= intent.getStringExtra(EXTRA_MESSAGE)
        val nombre_textView = findViewById<TextView>(R.id.nombreReserva)
        nombre_textView.text = nombre_reserva

        //Fecha
        val fecha_reserva= intent.getStringExtra(FECHA)
        val fecha_textView = findViewById<TextView>(R.id.fechaReserva)
        fecha_textView.text = fecha_reserva

        //Dinero
        val dinero_reserva= intent.getStringExtra(DINERO)
        val dinero_textView = findViewById<TextView>(R.id.dinero_reserva)
        dinero_textView.text = dinero_reserva+ " €"

        //Dias restantes
        val dias_restantes_reserva= intent.getStringExtra(DIAS_RESTANTES)
        val dias_restantes_textView = findViewById<TextView>(R.id.dias_restantes)

        if (dias_restantes_reserva== "1") {
            dias_restantes_textView.text = "Mañana"
        } else dias_restantes_textView.text = dias_restantes_reserva+ " Días"

        //Direccion
        val direccion_reserva = intent.getStringExtra(DIRECCION)
        val direccion_textView = findViewById<TextView>(R.id.direccion_reserva)
        direccion_textView.text = direccion_reserva



        //Botón de editar
        editar_reserva.setOnClickListener {
            val intent4 = Intent(this, MainActivity::class.java).putExtra(plusButtonState, "true").putExtra(
                editar, "true").putExtra("nombre", nombre_reserva).putExtra("fecha", fecha_reserva).putExtra("dinero", dinero_reserva).putExtra("direccion", direccion_reserva)
            intent4.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent4)
        }


        //Mecanismo para hallar la posicion
        var s = 0
        fun posicion(): Int{
            var b = 0
            while (s < reservas.size){

             if (reservas[s].nombre == nombre_reserva){

                 b = s
             }

                s++
            }
            return b
         }


        //Boton para eliminar la reserva
        eliminar_reserva.setOnClickListener {
            eliminarReserva(reservas[posicion()], posicion())
        }



        var mbottomNavigation: BottomNavigationView? = null

        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        val width = metrics.widthPixels // ancho absoluto en pixels
        val height = metrics.heightPixels // alto absoluto en pixels

        println("width: $width height: $height")


        mbottomNavigation = findViewById<View>(R.id.bottomNavigation) as BottomNavigationView

        if (width == 1080){
            mbottomNavigation.itemIconSize = 150
        }
        else if (width == 720){
            mbottomNavigation.itemIconSize = 100
        }


        mbottomNavigation.setOnNavigationItemSelectedListener { item ->
            if (item.itemId == R.id.home_button) {
                val intent1 = Intent(this, MainActivity::class.java)
                intent1.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent1)
            }
            if (item.itemId == R.id.plus_button) {
                val intent2 = Intent(this, MainActivity::class.java).putExtra(plusButtonState, "true").putExtra(
                    editar, "false")
                intent2.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent2)
            }
            if (item.itemId == R.id.graphics_button) {
                val intent3 = Intent(this, GraphicsActivity::class.java)
                intent3.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent3)
            }
            true
        }

    }

    fun eliminarReserva (reserva: Reserva, Posicion: Int){
        reservaDao.eliminarReserva(reserva)
        reservaAdapter.eliminarReserva(Posicion)
        val intent1 = Intent(this, MainActivity::class.java)
        intent1.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent1)
    }

    override fun onBackPressed() {
        // Añade más funciones si fuese necesario
        super.onBackPressed() // Invoca al método
        val intent = Intent(this, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
        startActivity(intent)
    }




}
