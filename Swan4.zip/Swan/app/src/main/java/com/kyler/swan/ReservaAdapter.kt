package com.kyler.swan

import android.app.*
import android.content.*
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.reserva_item.view.boton_reserva
import kotlinx.android.synthetic.main.reserva_item.view.dinero_boton
import kotlinx.android.synthetic.main.reserva_item.view.tiempo_restante

import java.util.*
import kotlin.collections.ArrayList

const val EXTRA_MESSAGE = "nombre_reserva"
const val FECHA = "fecha"
const val DINERO = "dinero"
const val DIAS_RESTANTES = "dias_restantes"
const val DIRECCION  = "direccion_reserva"

class ReservaAdapter(private var reservas: ArrayList<Reserva> = ArrayList(), private var contexto: Context) : RecyclerView.Adapter<ReservaAdapter.ReservaViewHolder>() {

    lateinit var plusActivity: PlusActivity

    lateinit var reservaInfo: Reserva_info

    private var pendingIntent: PendingIntent? = null



    fun agregarReserva(reserva: Reserva) {
        reservas.add(reserva)
        notifyItemInserted(itemCount)
    }

    fun setReservas(reservas : ArrayList<Reserva>) {
        this.reservas = reservas
        notifyDataSetChanged()
    }

    fun getReserva(posicion: Int) : Reserva {
        return reservas[posicion]
    }

    fun eliminarReserva(posicion: Int) {
        reservas.removeAt(posicion)
        notifyItemRemoved(posicion)
    }

    fun restaurarReserva(posicion: Int, reserva: Reserva) {
        reservas.add(posicion, reserva)
        notifyItemInserted(posicion)
    }

    fun cambiarPosicionItem(posicionInicial: Int, posicionFinal: Int) {
        val reserva= reservas[posicionInicial]
        reservas.removeAt(posicionInicial)
        reservas.add(posicionFinal, reserva)
        notifyItemMoved(posicionInicial, posicionFinal)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReservaViewHolder {
        return ReservaViewHolder(LayoutInflater.from(parent.context)
            .inflate(R.layout.reserva_item, parent, false), contexto)
    }

    override fun getItemCount(): Int {
        return reservas.size
    }

    override fun onBindViewHolder(holder: ReservaViewHolder, position: Int) { //
        holder.itemView.boton_reserva.text = "  " + reservas[position].nombre
        holder.itemView.dinero_boton.text = reservas[position].dinero +"€"


        plusActivity = PlusActivity()
        reservaInfo = Reserva_info()

        var tipo = reservas[position].tipo

        var diaText = reservas[position].fecha.substring(0, 2)

        var mesText = reservas[position].fecha.substring(3, 5)

        var añoText = reservas[position].fecha.substring(6, 10)


        println("fecha: " + reservas[position].fecha)
        println("longitud: " + reservas[position].fecha.count())

        var dia = reservas[position].fecha.substring(0, 2).toInt()
        var mes = reservas[position].fecha.substring(3, 5).toInt()
        var año = reservas[position].fecha.substring(6, 10).toInt()

        println("dia: " + dia + " mes: " + mes + " año: " + año)


        val c= Calendar.getInstance()
        val year= c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH) + 1
        val day = c.get(Calendar.DAY_OF_MONTH)
        println(day)
        println(month)

        var diaHoy = plusActivity.diaTotal(day.toInt(), month.toInt())
        var diaElegido = plusActivity.diaTotal(dia, mes)

        println(diaElegido)
        println(diaHoy)

        if (diaHoy >= diaElegido){
            println(dia)
            println(mes)


            var tiempoRestante = diaElegido - diaHoy



            if (tipo == "semanal"){
                println("semanal")
                dia = dia + 7
                diaText = "$dia"
            }
            else if (tipo == "mensual"){
                println("mensual")
                mes = mes + 1
                mesText = "$mes"
            }



            if (year != año){
                var añosRestantes = año - year

                if (añosRestantes != 0){ añosRestantes --}

                var diasAño = añosRestantes * 365

                var diasAñoRestantes = 366 - diaHoy

                tiempoRestante = diasAñoRestantes + diasAño + diaElegido

                if (diaElegido > 59){tiempoRestante --}
            }


            diaElegido = plusActivity.diaTotal(dia, mes)

            tiempoRestante = diaElegido - diaHoy

            if (tipo == "anual"){
                println("anual")
                año = año + 1
                añoText = "$año"
                tiempoRestante = tiempoRestante + 365
            }

            println(diaElegido)
            println(diaHoy)

            holder.bind(reservas[position], diaText, mesText, añoText, tiempoRestante)

            holder.itemView.tiempo_restante.text = tiempoRestante.toString() + " DÍAS"

        } else if (diaHoy < diaElegido){

            var tiempoRestante1 = diaElegido - diaHoy

            if (year != año){
                var añosRestantes = año - year

                if (añosRestantes != 0){ añosRestantes --}

                var diasAño = añosRestantes * 365

                var diasAñoRestantes = 366 - diaHoy

                tiempoRestante1 = diasAñoRestantes + diasAño + diaElegido

                if (diaElegido > 59){tiempoRestante1 --}
            }

            if (tiempoRestante1 == 1){
                holder.itemView.tiempo_restante.text = "MAÑANA"
                setPendingIntent(position, dia, mes, año, tiempoRestante1)
            } else  holder.itemView.tiempo_restante.text = tiempoRestante1.toString() + " DÍAS"


            holder.bind(reservas[position], diaText, mesText, añoText, tiempoRestante1)

        }


        }

    fun updateReservas(reservas: List<Reserva>){
        this.reservas = this.reservas
        notifyDataSetChanged()
    }


    fun setPendingIntent(posicion: Int, Dia: Int, Mes: Int, Año: Int, DiasRestantes: Int) {
        val intent = Intent(contexto, Reserva_info::class.java).putExtra(EXTRA_MESSAGE,reservas[posicion].nombre).putExtra(
            FECHA,"$Dia/$Mes/$Año").putExtra(DINERO, reservas[posicion].dinero).putExtra(DIAS_RESTANTES, DiasRestantes.toString()).putExtra(DIRECCION, reservas[posicion].direccion)
        val stackBuilder: TaskStackBuilder = TaskStackBuilder.create(contexto)
        stackBuilder.addParentStack(MainActivity::class.java)
        stackBuilder.addNextIntent(intent)
        pendingIntent = stackBuilder.getPendingIntent(1, PendingIntent.FLAG_UPDATE_CURRENT)


    }





    class ReservaViewHolder(private var vista: View,private var contexto:Context) : RecyclerView.ViewHolder(vista){
        fun bind (reserva: Reserva, Dia: String, Mes: String, Año: String, DiasRestantes: Int){
        //vista.boton_reserva.text = reserva.nombre




        vista.boton_reserva.setOnClickListener{
            contexto.startActivity(Intent(contexto, Reserva_info::class.java).putExtra(EXTRA_MESSAGE,reserva.nombre).putExtra(
                FECHA,"$Dia/$Mes/$Año").putExtra(DINERO, reserva.dinero).putExtra(DIAS_RESTANTES, DiasRestantes.toString()).putExtra(DIRECCION, reserva.direccion))
        }


        }

    }


    }