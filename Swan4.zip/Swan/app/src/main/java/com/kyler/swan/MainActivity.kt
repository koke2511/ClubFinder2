package com.kyler.swan

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceManager
import android.text.TextWatcher
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.widget.EditText
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.ads.MobileAds
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.analytics.FirebaseAnalytics
import com.kyler.swan.databinding.ActivityMainBinding
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.plus_layout.direccion


enum class ProviderType {
    BASIC,
    GOOGLE
}
var estadoInicio  = true

class MainActivity : AppCompatActivity(){

    val     plusButtonCode = 1

    private lateinit var binding: ActivityMainBinding

    lateinit var reservaAdapter: ReservaAdapter
    lateinit var mainLayout : CoordinatorLayout
    lateinit var reservaDao: ReservaDao



    override fun onCreate(savedInstanceState: Bundle?) {

        //Splash Screen
        Thread.sleep(100)
        setTheme(R.style.SplashTheme)

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(R.layout.activity_main)

        //var recycler_view = findViewById<RecyclerView>(R.id.recycler_view)

        MobileAds.initialize(this)


        //Firebase Google Analitycs
        val analitycs = FirebaseAnalytics.getInstance(this)
        val bundle = Bundle()
        bundle.putString("message", "Integracion de Firebase completa")
        analitycs.logEvent("InitScreen", bundle)




        if (estadoInicio == true){startActivity(Intent(this, LoginActivity::class.java))}



        //Añadir suscripción desde cualquier lado que no sea MainActivity
        val estadoNuevaReserva = intent.getStringExtra(plusButtonState)
        val editar1 = intent.getStringExtra(editar)

        println(editar1)
        println(estadoNuevaReserva)


        val nombre = intent.getStringExtra("nombre")
        val fecha = intent.getStringExtra("fecha")
        val dinero = intent.getStringExtra("dinero")
        val direccion = intent.getStringExtra( "direccion")

        if (estadoNuevaReserva == "false" && editar1 == "false"){
            println("Has entrado en el modo añadir")


            val intent2 = Intent(this, PlusActivity::class.java)
            intent2.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            startActivityForResult(intent2, plusButtonCode)

        } else if (estadoNuevaReserva == "true" && editar1 == "true"){
            println("Has entrado en el modo editar 1")

            val intent2 = Intent(this, PlusActivity::class.java).putExtra(
            "Editar", "true").putExtra("nombre", nombre).putExtra("fecha", fecha).putExtra("dinero", dinero).putExtra("direccion", direccion)
            intent2.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            startActivityForResult(intent2, plusButtonCode)
        }








        //integracion con la base de datos de room
        reservaDao = AppDatabase.getInstance(this).reservaDao()

        val reservas = ArrayList<Reserva>(reservaDao.getReservas())

        binding.etFilter.addTextChangedListener {userFilter ->
            //Log.i("aris", userFilter.toString())

            val reservasFiltered =
                reservas.toMutableList().filter { reserva -> reserva.nombre.lowercase().contains(userFilter.toString()) }
            reservaAdapter.updateReservas(reservasFiltered)

            //imprimeme el arraylist de discotecas filtrado
            Log.i("aris", reservasFiltered.toString())



        }



        reservaAdapter = ReservaAdapter(reservas,this)
        recycler_view.adapter = reservaAdapter
        recycler_view.layoutManager = LinearLayoutManager(this)
        recycler_view.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))

        val itemTouchHelperCallback = object : ItemTouchHelper.Callback() {
            override fun getMovementFlags(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder
            ): Int {
                return makeMovementFlags(ItemTouchHelper.UP.or(ItemTouchHelper.DOWN), ItemTouchHelper.RIGHT)
            }

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val posicionInicial = viewHolder.adapterPosition
                val posicionFinal = target.adapterPosition
                reservaAdapter.cambiarPosicionItem(posicionInicial, posicionFinal)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val posicion = viewHolder.adapterPosition
                val tarea = reservaAdapter.getReserva(posicion)
                reservaDao.eliminarReserva(tarea)
                reservaAdapter.eliminarReserva(posicion)
                val snackbar = Snackbar.make(findViewById(R.id.activity_content), "Eliminaste una tarea", Snackbar.LENGTH_LONG)
                snackbar.setAction("Deshacer") {
                    reservaDao.insertarReserva(tarea)
                    reservaAdapter.restaurarReserva(posicion, tarea)
                }
                snackbar.setActionTextColor(Color.YELLOW)
                //snackbar.apply {view.layoutParams = (view.layoutParams as CoordinatorLayout.LayoutParams).apply {setMargins(0, topMargin, rightMargin, 500)}}.show()
            }

        }

        val itemTouchHelper = ItemTouchHelper(itemTouchHelperCallback)
        itemTouchHelper.attachToRecyclerView(recycler_view)

        settings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity ::class.java))
        }



        //Barra de navegación inferior
        var mbottomNavigation: BottomNavigationView? = null

        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        val width = metrics.widthPixels // ancho absoluto en pixels
        val height = metrics.heightPixels // alto absoluto en pixels

        println("width: $width height: $height")


        mbottomNavigation = findViewById<View>(R.id.bottomNavigation) as BottomNavigationView

        if (width == 1080){
            mbottomNavigation.itemIconSize = 150
        }
        else if (width == 720){
            mbottomNavigation.itemIconSize = 100
        }

        mbottomNavigation!!.setOnNavigationItemSelectedListener { item ->
            if (item.itemId == R.id.home_button) {
                val intent1 = Intent(this, MainActivity::class.java)
                intent1.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent1)
            }
            if (item.itemId == R.id.plus_button) {
                val intent2 = Intent(this, PlusActivity::class.java)
                intent2.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivityForResult(intent2, plusButtonCode)
            }
            if (item.itemId == R.id.graphics_button) {
                val intent3 = Intent(this, GraphicsActivity::class.java)
                intent3.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent3)
            }
            true
        }



    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == plusButtonCode) {
            if(resultCode == Activity.RESULT_OK) {
                val reservaDescripcion = data!!.extras!!["editText_reserva"] as String
                val fecha = data!!.extras!!["fecha"] as String
                val dinero = data!!.extras!!["dinero"] as String
                val tipo = "no funciona"
                val direccion = data!!.extras!!["direccion"] as String



                val reservaCreada = Reserva(reservaDescripcion, fecha, dinero, tipo, direccion)
                reservaDao.insertarReserva(reservaCreada)
                reservaAdapter.agregarReserva(reservaCreada)
            }
        }
    }


}






