package com.kyler.swan

import android.app.*
import android.content.*
import android.graphics.Color
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.discoteca_item.view.boton_discoteca

import kotlinx.android.synthetic.main.reserva_item.view.boton_reserva


import java.util.*
import kotlin.collections.ArrayList


class DiscotecaAdapter(private var discotecas: ArrayList<Discoteca> = ArrayList(), private var contexto: Context) : RecyclerView.Adapter<DiscotecaAdapter.DiscotecaViewHolder>() {

    lateinit var plusActivity: PlusActivity

    private var pendingIntent: PendingIntent? = null



    fun agregarDiscoteca(discoteca: Discoteca) {
        discotecas.add(discoteca)
        notifyItemInserted(itemCount)
    }

    fun setDiscotecas(discotecas : ArrayList<Discoteca>) {
        this.discotecas = discotecas
        notifyDataSetChanged()
    }

    fun getDiscoteca(posicion: Int) : Discoteca {
        return discotecas[posicion]
    }

    fun eliminarDiscoteca(posicion: Int) {
        discotecas.removeAt(posicion)
        notifyItemRemoved(posicion)
    }

    fun restaurarDiscoteca(posicion: Int, discoteca: Discoteca) {
        discotecas.add(posicion, discoteca)
        notifyItemInserted(posicion)
    }

    fun cambiarPosicionItem(posicionInicial: Int, posicionFinal: Int) {
        val discoteca= discotecas[posicionInicial]
        discotecas.removeAt(posicionInicial)
        discotecas.add(posicionFinal, discoteca)
        notifyItemMoved(posicionInicial, posicionFinal)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DiscotecaViewHolder {
        return DiscotecaViewHolder(LayoutInflater.from(parent.context)
            .inflate(R.layout.discoteca_item, parent, false), contexto)
    }

    override fun getItemCount(): Int {
        return discotecas.size
    }

    override fun onBindViewHolder(holder: DiscotecaViewHolder, position: Int) { //
        holder.itemView.boton_discoteca.text = " " + discotecas[position].nombre

    }


    fun setPendingIntent(posicion: Int, Dia: Int, Mes: Int, Año: Int, DiasRestantes: Int) {
        val stackBuilder: TaskStackBuilder = TaskStackBuilder.create(contexto)
        stackBuilder.addParentStack(MainActivity::class.java)
        pendingIntent = stackBuilder.getPendingIntent(1, PendingIntent.FLAG_UPDATE_CURRENT)


    }

    class DiscotecaViewHolder(private var vista: View,private var contexto:Context) : RecyclerView.ViewHolder(vista){
        fun bind (discoteca: Discoteca){
            //vista.boton_discoteca.text = discoteca.nombre



        }

    }


}