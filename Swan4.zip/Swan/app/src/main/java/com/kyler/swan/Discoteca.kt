package com.kyler.swan

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "discoteca")
data class Discoteca(
    @PrimaryKey val nombre: String,
    var direccion : String
)